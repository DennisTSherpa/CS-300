﻿//============================================================================
// Name        : ProjectTwo.cpp
// Author      : Dennis T Sherpa
// Version     : 1.0
// Copyright   : Copyright � 2024 Dennis T Sherpa
// Description : Project Two
//============================================================================

/*
    Before reading: 1. I will aim to keep my comments to a single line.
                            a. If a more in-depth explanation is required, please let me know because I am able and ready to provide it as another paper 
                               (in addition to my code reflection and pseudocode document submitted in module six).
                            b. Providing paragraph long comments explaining code disrupts the reading flow of code. Furthermore, my code reflection and pseudocode document (previously submitted in module six)
                               answers all the questions posed by Project Two regarding my code. If additional questions must be answered please let me know and I will answer all because I am able and ready.              
*/

#include <iostream> // FOR input/output (cin, cout)
#include <string> // FOR using std::string
#include <vector> // FOR dynamic arrays (vectors)
#include <sstream> // FOR string stream operations
#include <fstream> // FOR file input/output
#include <algorithm> // FOR algorithms like transform
#include <cctype> // FOR character handling (e.g., case conversion)

// To avoid prefixing standard library functions and objects with "std::"
using namespace std;

// STRUCTURE of a Course object
struct Course {
    // STRING VARIABLES: courseNumber, courseName
    string courseNumber, courseName;
    // VECTOR of STRINGS named prereqCourseNumbers
    vector<string> prereqCourseNumbers;
};

// STRUCTURE of a Node pointer
struct Node {
    // INITIALIZE a course object
    Course course;
    // INTIAIZLIZE two node pointers named left and right
    Node* left, *right;

    // DEFAULT CONSTRUCTOR
    Node() {
        // POINT left to a null pointer
        left = nullptr;
        // POINT right to a null pointer
        right = nullptr;
    }

    // INITIALIZE a node's course with aCourse plus the INITIALIZATIONS done in the default constructor
    Node(Course aCourse):Node() {
        // ASSIGN course with aCourse
        course = aCourse;
    }
};

// CLASS of a Binary Search Tree
class BinarySearchTree {
    // PRIVATE variable and methods
    private:
        // INTIALIZE a node pointer root, which will be the root node of the Binary Search Tree
        Node* root;
        // ADDS a node to the Binary Search Tree, whose root node does not point to a null pointer
        void addNode(Node* aNode, Course aCourse);
        // PRINTS all courses in alphanumeric order
        void printAll(Node* aNode);

    // PUBLIC methods
    public:
        // DEFAULT CONSTRUCTOR
        BinarySearchTree();
        // DESTRUCTOR
        virtual ~BinarySearchTree();
        // DELETES all nodes in the Binary Search Tree (recusively if needed)
        void clear(Node* node);
        // CHECKS if a prerequisite course exists as a course
        bool checkCourseExists(string prereqCourseNumber);
        // CHECKS if the file is formatted correctly
        bool checkFileFormat(ifstream &file);
        // INSERTS a node into the Binary Search Tree
        void insertNode(Course aCourse);
        // LOADS a file into a Binary Search Tree
        void loadFile();
        // CALLS printAll(Node* aNode) to PRINT all courses in alphanumeric order
        void inOrder();
        // SEARCHES for a course requested by the user
        Course searchCourse(string courseNumber);
};

// PRIVATE METHODS

// ADD a node to a Binary Search Tree
void BinarySearchTree::addNode(Node* aNode, Course aCourse) {
    // IF aNode points to a course whos course number is greater than aCourse's course number
    if (aNode->course.courseNumber > aCourse.courseNumber) {
        // IF aNode's left child equals a null pointer
        if (aNode->left == nullptr) {
            // ASSIGN aNode's left child with a new node that points to aCourse
            aNode->left = new Node(aCourse);
        }
        // ELSE
        else {
            // RECURSIVELY CALL addNode(w/ arguments: aNode's left child, aCourse)
            addNode(aNode->left, aCourse);
        }
    }
    // ELSE
    else {
        // IF aNode's right child equals a null pointer
        if (aNode->right == nullptr) {
            // ASSIGN aNode's right child with a new node that points to aCourse
            aNode->right = new Node(aCourse);
        }
        // ELSE
        else {
            // RECURSIVELY CALL addNode(w/ arguments: aNode's right child, aCourse)
            addNode(aNode->right, aCourse);
        }
    }
}

// PRINT ALL nodes in a Binary Search Tree in order
void BinarySearchTree::printAll(Node* aNode) {
    // IF aNode does not equal a null pointer
    if (aNode != nullptr) {
        // RECURSIVELY CALL printAll(w/ argument: aNode's left child)
        printAll(aNode->left);
        // OUTPUT aNode's course information
        cout << aNode->course.courseNumber << ", " << aNode->course.courseName << endl;
        // RECURSIVELY CALL printAll(w/ argument: aNode's right child)
        printAll(aNode->right);
    }
}

// PUBLIC METHODS

// DEFAULT CONSTRUCTOR for a Binary Search Tree
BinarySearchTree::BinarySearchTree() {
    // INITIALIZE the root to a nullptr
    root = nullptr;
}

// DESTRUCTOR
BinarySearchTree::~BinarySearchTree() {
    // CALLS clear(w/ argument: root node)
    clear(root);
}

// DELETE all nodes in the Binary Search Tree (recursively if needed)
void BinarySearchTree::clear(Node* node) {
    // IF node's left child does not equal null THEN
    if (node->left != nullptr) {
        // CALL clear by passing node's left child
        clear(node->left);
    }

    // IF node's right child does not equal null THEN
    if (node->right != nullptr) {
        // CALL clear by passing node's right child
        clear(node->right);
    }

    // Delete node
    delete node;
}

// CHECK if a prerequisite course exists as a course
bool BinarySearchTree::checkCourseExists(string prereqCourseNumber) {
    // INITIALIZE a string variable named line, which will store each line of the file
    string line;
    // OPEN the CSV file as tempFile
    ifstream tempFile("CS 300 ABCU_Advising_Program_Input.csv");

    // WHILE getting a line from tempFile does not prove false
    while (getline(tempFile, line)) {
        // STORE the line from the file as a string into words
        stringstream words(line);
        // INITIALIZE a string named token
        string token;
        // STORE a word, a string until the delimiter ',' from words, into token
        getline(words, token, ',');
        // IF the string in token is equal to the string in prereqCourseNumber
        if (token == prereqCourseNumber) {
            // RETURN true
            return true;
        }
    }

    // CLOSE the tempFile
    tempFile.close();
    // RETURN false
    return false;
}

// CHECK if a file is formatted correctly
bool BinarySearchTree::checkFileFormat(ifstream &file) {
    // INITIALIZES a boolean variable named prereqCourseExists
    bool prereqCourseExists;
    // INITIALIZES two string variables named prereqCourseExists and line
    string prereqCourseNumber, line;
    // INITIALIZE a string variable named token
    string token;
    // INITIALIZE a vector of strings named tokensInLine
    vector<string> tokensInLine;
    // INITIALIZE an integer variable named count
    int count;

    // WHILE getting a line from the file does not prove false
    while (getline(file, line)) {
        // EMPTY vector before use
        tokensInLine.clear();
        // INITIALIZE count to zero before use
        count = 0;
        // STORE the line from the file as a string into words
        stringstream words(line);

        // WHILE storing a word, a string until the delimiter ',' from words, into token does not prove false
        while (getline(words, token, ',')) {
            // PUSH BACK a token into tokensInLine
            tokensInLine.push_back(token);
            // INCREMENT count by one
            ++count;
        }

        // IF count is less than two
        if (count < 2) {
            // OUTPUT file format incorrect
            cout << "File formatted incorrectly." << endl;
            // RETURN false
            return false;
        }

        // IF count is greater than two
        if (count > 2) {
            /* FOR LOOP: 
                        * where an integer i is INITIALIZED to two (index from where the list of prerequisite courses should start)
                        * WHILE i is less than the size of tokensInLine
                        * INCREMENT i by one after each iteration
             */
            for (unsigned int i = 2; i < tokensInLine.size(); ++i) {
                // ASSIGN prereqCourseNumber with the string at index i of tokensInLine
                prereqCourseNumber = tokensInLine.at(i);
                // ASSIGN prereqCourseExists with the return value from CALLING checkCourseExists(w/ arguments: file, prereqCourseNumber)
                prereqCourseExists = checkCourseExists(prereqCourseNumber);
                // IF prereqCourseExists does not equal true
                if (prereqCourseExists != true) {
                    // OUTPUT that the prerequisite course does not exists as a course
                    cout << prereqCourseNumber << " does not exist as a course." << endl;
                    // RETURN false
                    return false;
                }
            }
        }
    }

    // RETURN true
    return true;
}

// INSERT a node containing a specific course to a Binary Search Tree
void BinarySearchTree::insertNode(Course aCourse) {
    // IF the root node equals a null pointer
    if (root == nullptr) {
        // SET the root node's course to aCourse
        root = new Node(aCourse);
    }
    // ELSE
    else {
        // ADD a node containing aCourse to the Binary Search Tree, where the root is the argument root
        addNode(root, aCourse);
    }
}

// LOAD a file into a Binary Search Tree
void BinarySearchTree::loadFile() {
    // OPEN the CSV file as file
    ifstream file("CS 300 ABCU_Advising_Program_Input.csv");

    // INITIALIZE four string variables named prereqCourseNumber, line, words, and token
    string prereqCourseNumber, line, words, token;
    // INITIALIZE an integer variable to keep track of number of tokens
    int count;

    // WHILE getting a line from the file does not prove false
    while (getline(file, line)) {
        // CREATE a new Course object called course
        Course course;
        // INITIALIZE count to zero
        count = 0;
        // STORE the line from the file as a string into words
        stringstream words(line);

        // PARSE the line into tokens by commas
        while (getline(words, token, ',')) {
            // IF count equals zero, the token holds a course's course number
            if (count == 0) {
                // STORE the course number into the course object's courseNumber
                course.courseNumber = token;
            }
            // ELSE IF count equals one, the token holds a course's course name
            else if (count == 1) {
                // STORE the course name into the course object's courseName
                course.courseName = token;
            }
            // ELSE IF count is greater than one, the token holds a course's prerequisite course
            else if (count > 1) {
                // PUSH BACK the prerequisite course into the course object's prereqCourseNumbers vector
                course.prereqCourseNumbers.push_back(token);
            }
            // INCREMENT count by one
            ++count;
        }
        // INSERT this course into the Binary Search Tree
        insertNode(course);
    }

    // NOTIFY user that the file has been loaded
    cout << "File has been loaded." << endl;
    // CLOSE file
    file.close();
}

// OUTPUT all nodes in a Binary Search Tree in order. In other words, print the list of courses in alphanumeric order
void BinarySearchTree::inOrder() {
    // INTRODUCE the list of courses
    cout << "The following is the list of courses in alphanumeric order:\n" << endl;

    // CALL printAll(w/ argument: root node) to print all nodes of a Binary Search Tree in order
    printAll(root);
}

// SEARCH for a specific course in the Binary Search Tree
Course BinarySearchTree::searchCourse(string courseNumber) {
    // INITIALIZE a node pointer named cur and point it to the root node
    Node* cur = root;

    // WHILE cur does not point to a null pointer
    while (cur != nullptr) {
        // IF cur points to a course with a course number that matches the courseNumber
        if (cur->course.courseNumber == courseNumber) {
            // Initialize a course object named course to the course that cur points to
            Course course = cur->course;
            // RETURN the course cur points to
            return course;
        }
        
        // IF courseNumber is less than the course number of the course that cur points to
        if (courseNumber < cur->course.courseNumber) {
            // ASSIGN cur with its left child
            cur = cur->left;
        }
        // ELSE IF courseNumber is greater than the course number of the course that cur points to
        else if (courseNumber > cur->course.courseNumber) {
            // ASSIGN cur with its right child
            cur = cur->right;
        }
    }

    // CREATE a Course object named course
    Course course;
    // RETURN an empty course object to notify that the course with the courseNumber could not be found
    return course;
}

// The main function
int main()
{
    // INITIALIZE a Binary Search Tree pointer named bst to the return value from CALLING a new instance of the default constructor
    BinarySearchTree* bst = new BinarySearchTree();
    // INITIALIZE a Course object named course
    Course course;
    // INITIALIZE a string variable named specificCourseNumber
    string specificCourseNumber;
    // INITIALIZE a string variable to hold a prerequisite course (used in case 3)
    string prereqCourse;
    // INITIALIZE a boolean variable name fileLoaded, to check if a file has been loaded, to false
    bool fileLoaded = false;

    // Open the file as file
    ifstream file("CS 300 ABCU_Advising_Program_Input.csv");

    // IF the file could not opened
    if (!file.is_open()) {
        // NOTIFY user of error
        cout << "The file could not be opened" << endl;
        // RETURN -1 to end program with an error
        return -1;
    }

    // INITIALIZE a boolean variable named fileFormat to the return value from POINTING bst to checkFileFormat(w/ argument: file), which will check if the file is formatted correctly
    bool fileFormat = bst->checkFileFormat(file);

    // IF the file is formatted incorrectly
    if (!fileFormat) {
        // NOTIFY user of error
        cout << "File formatted incorrectly." << endl;
        // RETURN -1 to end program with an error
        return -1;
    }

    // CLOSE file
    file.close();

    // INITIALIZE an integer variable named choice to zero
    int choice = 0;

    // WHILE choice does not equal nine
    while (choice != 9) {
        // OUTPUT menu
        cout << "\nMenu: " << endl;
        cout << "     1. Load Courses." << endl;
        cout << "     2. Display All Courses." << endl;
        cout << "     3. Find a Specific Course." << endl;
        cout << "     9. Exit." << endl;

        // WHILE LOOP until user enters an integer
        while (true) {
            // ASK user to enter their choice
            cout << "\nEnter your choice: ";

            // IF the input can be STORED into choice
            if (cin >> choice) {
                // BREAK from this while loop
                break;
            }
            // ELSE
            else {
                // NOTIFY user of invalid input and ask to enter a valid input
                cout << "Invalid input. Please enter a number." << endl;;

                // CLEAR error state
                cin.clear();
                // IGNORE invalid input until the next newline
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
            }
        }

        // START on a new line
        cout << endl;

        // SWITCH case according to choice. In other words, run the case that matches the choice's value
        switch (choice) {
            // CASE 1: LOAD all courses into a Binary Search Tree
            case 1:
                // IF the file has not been loaded yet
                if (fileLoaded == false) {
                    // POINT bst to loadFile(), which loads the file into a Binary Search Tree
                    bst->loadFile();
                    // SET fileLoaded to true
                    fileLoaded = true;
                }
                // ELSE
                else {
                    // NOTIFY user that the file has already been loaded
                    cout << "The file has already been loaded." << endl;
                }

                // BREAK from this case to return to the while conditional statement
                break;
            
            // CASE 2: DISPLAY all courses in a Binary Search Tree
            case 2:
                // POINT bst to inOrder() to print all courses in a Binary Search Tree in alphanumeric order
                bst->inOrder();
                
                // BREAK from this case to return to the while conditional statement
                break;

            // CASE 3: FIND a specific course in a Binary Search Tree
            case 3:
                // ASK user to enter a course number
                cout << "Enter a course number: ";
                // INSERT input into specificCourseNumber
                cin >> specificCourseNumber;
                // START on a new line
                cout << endl;

                // CONVERT specificCourseNumber to all upper case
                transform(specificCourseNumber.begin(), specificCourseNumber.end(), specificCourseNumber.begin(), ::toupper);

                // ASSIGN course with the return value from POINTING bst to searchCourse(w/ argument: specificCourseNumber)
                course = bst->searchCourse(specificCourseNumber);

                // INITIALIZE a boolean variable named hasPrereqCourses with false
                bool hasPrereqCourses = false;

                // IF course is not empty
                if (!course.courseNumber.empty()) {

                    // OUTPUT course information according to the sample output format
                    cout << course.courseNumber << ", " << course.courseName << endl;

                    // IF the course has prerequisites
                    if (course.prereqCourseNumbers.size() > 0) {
                        // ASSIGN hasPrereqCourses with true
                        hasPrereqCourses = true;
                    }
                    
                    // IF hasPrereqCourses equals true
                    if (hasPrereqCourses == true) {
                        // OUTPUT prerequisites according to the sample output format
                        cout << "Prerequisites:";
                        
                        // FOR each prereqCourse in the course
                        for (string prereqCourse : course.prereqCourseNumbers) {
                            
                            // IF the prereqCourse holds the last prerequisite course in prereqCourseNumbers
                            if (prereqCourse == course.prereqCourseNumbers.at(course.prereqCourseNumbers.size() - 1)) {
                                // OUTPUT a space and the prereqCourse
                                cout << " " << prereqCourse << endl;
                            }

                            // ELSE
                            else {
                                // OUTPUT a space, prereqCourse, and a comma
                                cout << " " << prereqCourse << ",";
                            }
                        }
                    }
                    // ELSE
                    else {
                        // NOTIFY user that this course does not have prerequisites
                        cout << course.courseName << " has no prerequisites." << endl;
                    }
                    
                }
                // ELSE
                else {
                    // NOTIFY user to enter a valid course number
                    cout << "Please enter a valid course number next time." << endl;
                }

                // BREAK from this case to return to the while conditional statement
                break;
        }
    }

    // OUTPUT end of program
    cout << "End of program." << endl;
    // RETURN zero to end
    return 0;
}

